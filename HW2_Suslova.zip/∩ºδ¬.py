import codecs
import collections
import sys
import wikipedia
from itertools import islice, tee


def get_texts_for_lang(lang, n=10): # функция для скачивания статей из википедии
    wikipedia.set_lang(lang)
    wiki_content = []
    pages = wikipedia.random(n)
    for page_name in pages:
        try:
            page = wikipedia.page(page_name)
        except wikipedia.exceptions.WikipediaException:
            print('Skipping page {}'.format(page_name))
            continue

        wiki_content.append('{}\n{}'.format(page.title, page.content.replace('==', '')))

    return wiki_content

 # скачиваем по 100 статей для каждого языка. Это может занять какое-то время (5-10 минут. как правило)

wiki_texts = {}
for lang in ('ru', 'it', 'fr', 'uk'): 
    wiki_texts[lang] = get_texts_for_lang(lang, 100)
    #print(lang, len(wiki_texts[lang]))

print(wiki_texts['it'][0]) # распечатаем пару текстов, чтобы убедиться, что все хорошо
print(wiki_texts['ru'][0])



def tokenize(text):
    return text.split(' ')

freqs_fr = collections.defaultdict(lambda: 0)
corpusfr = wiki_texts['fr']
for article in corpusfr:
    for word in tokenize(article.replace('\n', '').lower()):
        freqs_fr[word] += 1

freqs_it = collections.defaultdict(lambda: 0)
corpusit = wiki_texts['it']
for article in corpusit:
    for word in tokenize(article.replace('\n', '').lower()):
        freqs_it[word] += 1

freqs_uk = collections.defaultdict(lambda: 0)
corpusuk = wiki_texts['uk']
for article in corpusuk:
    for word in tokenize(article.replace('\n', '').lower()):
        freqs_uk[word] += 1

freqs_ru = collections.defaultdict(lambda: 0)
corpusru = wiki_texts['ru']
for article in corpusru:
    for word in tokenize(article.replace('\n', '').lower()):
        freqs_ru[word] += 1
        
dfr = set()
for word in sorted(freqs_fr, key=lambda w: freqs_fr[w], reverse=True):
    if word not in freqs_it and word not in freqs_ru and word not in freqs_uk:
        dfr.add(word)
    if len(dfr) > 499:
        break

dit = set()
for word in sorted(freqs_it, key=lambda w: freqs_it[w], reverse=True):
    if word not in freqs_fr and word not in freqs_ru and word not in freqs_uk:
        dit.add(word)
    if len(dit) > 499:
        break

dru = set()
for word in sorted(freqs_fr, key=lambda w: freqs_ru[w], reverse=True):
    if word not in freqs_it and word not in freqs_fr and word not in freqs_uk:
        dru.add(word)
    if len(dru) > 499:
        break

duk = set()
for word in sorted(freqs_fr, key=lambda w: freqs_uk[w], reverse=True):
    if word not in freqs_it and word not in freqs_ru and word not in freqs_fr:
        duk.add(word)
    if len(duk) > 499:
        break






def make_ngrams(text):
    N = 3 # задаем длину n-граммы
    ngrams = zip(*(islice(seq, index, None) for index, seq in enumerate(tee(text, N))))
    ngrams = [''.join(x) for x in ngrams]
    return ngrams

ngrfreqs_fr = collections.defaultdict(lambda: 0)
corpusfr2 = wiki_texts['fr']
for article in corpusfr2:
    for ngram in make_ngrams(article.replace('\n', '').lower()):
        ngrfreqs_fr[ngram] += 1
        
ngrfreqs_ru = collections.defaultdict(lambda: 0)
corpusru2 = wiki_texts['ru']
for article in corpusru2:
    for ngram in make_ngrams(article.replace('\n', '').lower()):
        ngrfreqs_ru[ngram] += 1
        
ngrfreqs_it = collections.defaultdict(lambda: 0)
corpusit2 = wiki_texts['it']
for article in corpusit2:
    for ngram in make_ngrams(article.replace('\n', '').lower()):
        ngrfreqs_it[ngram] += 1
        
ngrfreqs_uk = collections.defaultdict(lambda: 0)
corpusuk2 = wiki_texts['uk']
for article in corpusuk2:
    for ngram in make_ngrams(article.replace('\n', '').lower()):
        ngrfreqs_uk[ngram] += 1

ngramru = set()
for ngram in sorted(ngrfreqs_ru, key=lambda n: ngrfreqs_ru[n], reverse=True):
    if ngram not in ngrfreqs_uk and ngram not in ngrfreqs_fr and ngram not in ngrfreqs_it:
        ngramru.add(ngram)
    if len(ngramru) > 499:
        break
        
ngramit = set()
for ngram in sorted(ngrfreqs_it, key=lambda n: ngrfreqs_it[n], reverse=True):
    if ngram not in ngrfreqs_uk and ngram not in ngrfreqs_fr and ngram not in ngrfreqs_ru:
        ngramit.add(ngram)
    if len(ngramit) > 499:
        break
        
ngramuk = set()
for ngram in sorted(ngrfreqs_uk, key=lambda n: ngrfreqs_uk[n], reverse=True):
    if ngram not in ngrfreqs_ru and ngram not in ngrfreqs_fr and ngram not in ngrfreqs_it:
        ngramuk.add(ngram)
    if len(ngramuk) > 499:
        break
        
ngramfr = set()
for ngram in sorted(ngrfreqs_fr, key=lambda n: ngrfreqs_fr[n], reverse=True):
    if ngram not in ngrfreqs_uk and ngram not in ngrfreqs_ru and ngram not in ngrfreqs_it:
        ngramfr.add(ngram)
    if len(ngramfr) > 499:
        break


wiki_texts_new = {}
for lang in ('ru', 'it', 'fr', 'uk'): 
    wiki_texts_new[lang] = get_texts_for_lang(lang, 100)

mist = 0
for i in wiki_texts_new:
    for i2 in range(len(wiki_texts_new[i])-1):
        text = set(tokenize(wiki_texts_new[i][i2]))
        arr = []  
        ru = len(text & dru)
        arr.append(ru)
        it = len(text & dit)
        arr.append(it)
        fr = len(text & dfr)
        arr.append(fr)
        uk = len(text & duk)
        arr.append(uk)
        maximum= max(arr)
        if maximum == arr[0]:
            yaz = 'ru'
        elif maximum == arr[1]:
            yaz = 'it'
        elif maximum == arr[2]:
            yaz = 'fr'
        else:
            yaz = 'uk'
        if yaz != i:
            mist += 1

s = 0
for i in wiki_texts_new:
    s += len(wiki_texts_new[i])
print((mist)/s)

mist2 = 0
for i in wiki_texts_new:
    for i2 in range(len(wiki_texts_new[i])-1):
        text2 = set(make_ngrams(wiki_texts_new[i][i2]))
        arr2 = []  
        ru2 = len(text2 & ngramru)
        arr2.append(ru2)
        it2 = len(text2 & ngramit)
        arr2.append(it2)
        fr2 = len(text2 & ngramfr)
        arr2.append(fr2)
        uk2 = len(text2 & ngramuk)
        arr2.append(uk2)
        maximum = max(arr2)
        if maximum == arr2[0]:
            yaz2 = 'ru'
        elif maximum == arr2[1]:
            yaz2 = 'it'
        elif maximum == arr2[2]:
            yaz2 = 'fr'
        else:
            yaz2 = 'uk'
        if yaz != i:
            mist2 += 1

print((mist2)/s)

def slovar(text):
    text_= set(tokenize(text))
    arr = []  
    ru = len(text_ & dru)
    arr.append(ru)
    it = len(text_ & dit)
    arr.append(it)
    fr = len(text_ & dfr)
    arr.append(fr)
    uk = len(text_ & duk)
    arr.append(uk)
    maximum = max(arr)
    if maximum == arr[0]:
        yaz = 'ru'
    elif maximum== arr[1]:
        yaz = 'it'
    elif maximum == arr[2]:
        yaz = 'fr'
    else:
        yaz = 'uk'
    return yaz

def opr_ngr(text):
    text2 = set(make_ngrams(text))
    arr2 = []  
    ru2 = len(text2 & ngramru)
    arr2.append(ru2)
    it2 = len(text2 & ngramit)
    arr2.append(it2)
    fr2 = len(text2 & ngramfr)
    arr2.append(fr2)
    uk2 = len(text2 & ngramuk)
    arr2.append(uk2)
    maximum = max(arr2)
    if maximum == arr2[0]:
        yaz2 = 'ru'
    elif maximum == arr2[1]:
        yaz2 = 'it'
    elif maximum == arr2[2]:
        yaz2 = 'fr'
    else:
        yaz2 = 'uk'
    return yaz2


def det_lang(text):
    t1 = slovar(text)
    t2 = opr_ngr(text)
    return t1,t2


t = 'Игра является продолжением первой Sonic Riders. Игровой процесс сиквела не подвергся кардинальным изменениям: от игрока требуется пройти несколько трасс на воздушной доске «Extreme Gear», совершая по пути трюки и собирая золотые кольца. По сюжету, команды Героев и Вавилона устроили поединок, чтобы решить спор о принадлежности сокровищ в виде легендарных артефактов Ковчега Космоса, обладающих способностью управлять гравитацией. Помимо режима истории, в Sonic Riders: Zero Gravity представлены различные миссии и задания, открывающие доступ к новым воздушным доскам и персонажам, а также мультиплеер. Каждый персонаж в игре относится к одному из трёх типов: скорости, полёту или силе.'
t3 = "La valle copre un'estensione di circa 0,7 km² ed è costituita da uno wadi scavato da antichi fiumi e dalle piogge che erosero il calcare. Di fatto è costituita, topograficamente, da due rami separati: mentre il ramo principale, orientale, ospita la maggior parte delle tombe reali oggi note, il ramo occidentale più ampio, e noto come west valley, ospita ad oggi un numero molto ridotto di sepolture."
print(det_lang(t))
print(det_lang(t3))
